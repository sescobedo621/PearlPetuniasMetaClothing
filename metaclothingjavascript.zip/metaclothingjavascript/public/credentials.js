module.exports = {
  cookieSecret: "banana"
};
